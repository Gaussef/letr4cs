import ix
ix.main()